<?php
/**
 * Created by PhpStorm.
 * User: keljo
 * Date: 4/27/2017
 * Time: 3:37 PM
 */

//mysql credentials and login
$host="localhost";
$username= "root";
$password="password";
$db="restaurant";
$mysqli = new mysqli($host, $username, $password, $db);

?>