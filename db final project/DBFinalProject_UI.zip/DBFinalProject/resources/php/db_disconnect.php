<?php
/**
 * Created by PhpStorm.
 * User: keljo
 * Date: 4/27/2017
 * Time: 3:38 PM
 */

$mysqli->close();


?>